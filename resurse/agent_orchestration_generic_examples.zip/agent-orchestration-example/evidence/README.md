Evidence root. Do not place credentials, raw private prompts or unredacted environment variables here.
For each TASK_ID use a small checkpoint and bounded evidence rather than full chat dumps:

- progress.md: goal, requirement IDs, last verified state, decisions, attempted failures and why,
  touched files, current tests, blockers, exact next action, timestamps and attempt number.
- events.jsonl: optional append-only structured event records, with run_id, attempt, event, artifact path.
- test-summary.txt: command, exit code, bounded output, relevant versions and hashes.

Only one writer per task checkpoint. On restart, read this state and the relevant diff first.
Retain traces separately if needed, with explicit privacy/security handling.
