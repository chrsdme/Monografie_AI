# Generic evidence-first orchestrator

User prompt -> MAIN requirement ledger -> dependency graph + Task Packets -> fresh bounded workers -> focused tests -> independent verifier -> MAIN acceptance + final reconciliation.

Worker statuses: CLAIMED_DONE / PARTIAL / BLOCKED / FAILED / NEEDS_DECISION.
Verifier statuses per requirement: PASS / FAIL / NOT_VERIFIED.
MAIN statuses per requirement: ACCEPTED / BLOCKED / DEFERRED; DEFERRED requires an explicit owner decision or pre-approved policy, never just a worker choice. Main task is COMPLETE only if every requirement is ACCEPTED. With BLOCKED or DEFERRED, report PARTIAL or BLOCKED with remaining scope; never "DONE" with open work.

Practical task sizing: 25 substantive operations is an initial heuristic, not a supported property of all agent SDKs. If >=18/25 operations, converge, prioritize targeted tests and evidence. At ~20/25 with unfinished work, persist and return PARTIAL so a new worker can take over. maxTurns is model/agent turns, not identical to operations or tokens. Do not split a coherent fix arbitrarily because of a round number: use bounded scope, dependencies, observed latency, and test granularity.

Checkpoint strategy: at first meaningful step write progress.md; on every substantive test/finding record event; on partial include exact next actions, rejected hypotheses, commands already attempted, file changes and independent evidence. On resume, create fresh worker instance; feed requirement IDs, compact task packet, progress.md, changed-file diff and referenced evidence only, never the entire predecessor transcript. Keep logs redacted and size-limited. Persist process state in files/DB, never exclusively in LLM memory.

If two workers need to edit the same paths, serialize or isolate branches/worktrees and reconcile separately. Inspect tool permissions at the platform boundary; a text instruction stating "read-only" does not constitute a security sandbox. For Code/Codex the agent TOML does not enforce all per-worker sandbox modes: apply session/workspace policy separately. For Claude, outer permission mode can override the subagent's requested permission mode.

Source documentation (checked October 2026):
Claude Code: https://code.claude.com/docs/en/sub-agents
Codex: https://developers.openai.com/codex/multi-agent
OpenAI Agents SDK: https://openai.github.io/openai-agents-python/
Pydantic AI: https://pydantic.dev/docs/ai/guides/multi-agent-applications/
LangGraph persistence: https://docs.langchain.com/oss/python/langgraph/persistence
