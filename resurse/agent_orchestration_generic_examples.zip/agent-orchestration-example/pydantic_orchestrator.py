"""Illustrative Pydantic AI manager/worker/verifier handshake.

Requires `pip install pydantic-ai` and valid provider credentials for the selected models.
This is a delegation CONTRACT demo, not a coding agent: there are no file-editing
or test-execution tools wired. Therefore a verifier must not claim independent
source/test verification from the worker summary alone. Add scoped tools and a
trusted, deterministic acceptance runner before using it for code changes.
"""

import asyncio
from typing import Literal
from pydantic import BaseModel, Field
from pydantic_ai import Agent, UsageLimits


class WorkerReport(BaseModel):
    task_id: str
    status: Literal['CLAIMED_DONE', 'PARTIAL', 'BLOCKED', 'FAILED', 'NEEDS_DECISION']
    requirement_ids: list[str]
    evidence_paths: list[str] = Field(default_factory=list)
    remaining: list[str] = Field(default_factory=list)
    exact_next: str = ''


class Criterion(BaseModel):
    requirement_id: str
    result: Literal['PASS', 'FAIL', 'NOT_VERIFIED']
    evidence: str = ''


class VerificationReport(BaseModel):
    criteria: list[Criterion]


worker = Agent(
    'openai:gpt-6-luna',
    name='worker',
    output_type=WorkerReport,
    instructions='Handle one bounded task. You cannot award ACCEPTED. '
                 'Without configured write or test tools, do not claim real edits or tests.',
)
verifier = Agent(
    'openai:gpt-6-luna',
    name='verifier',
    output_type=VerificationReport,
    instructions='Assess supplied criteria independently. With no tool access, '
                 'return NOT_VERIFIED for any claim requiring file or runtime inspection. '
                 'A worker report by itself is not proof.',
)


async def coordinate(task_packet: str) -> tuple[WorkerReport, VerificationReport]:
    # No message_history is passed: a new run starts with selected input only.
    worker_result = await worker.run(
        task_packet, usage_limits=UsageLimits(request_limit=12)
    )
    reviewer_result = await verifier.run(
        f'Original task:\n{task_packet}\nWorker claim:\n'
        f'{worker_result.output.model_dump_json()}',
        usage_limits=UsageLimits(request_limit=6),
    )
    # The application, not the LLM, should persist reports and enforce
    # deterministic acceptance checks. This example intentionally does not
    # return ACCEPTED merely because the verifier said PASS.
    return worker_result.output, reviewer_result.output


if __name__ == '__main__':
    work, verification = asyncio.run(coordinate(
        'TASK_ID=T-001; R-01: explain how to test whitespace normalization. '
        'Do not claim to have changed files or run tests.'
    ))
    print('Worker:', work.model_dump_json(indent=2))
    print('Verifier:', verification.model_dump_json(indent=2))
