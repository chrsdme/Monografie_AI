# Bounded multi-agent orchestration example

Generic public example derived from principles, not an exported personal project.

Layout:
- `.claude/agents/{explorer,implementer,verifier}.md`: native Claude Code frontmatter.
- `.codex/config.toml` and `.codex/agents/{explorer,implementer,verifier}.toml`: native Codex config.
- `pydantic_orchestrator.py`: typed Pydantic AI delegation CONTRACT, not an autonomous coding harness.
- `task_packet.example.json`: task packet schema illustration.
- `WORKFLOW.md`: orchestration logic, status owner, budget and checkpoint policy.
- `evidence/README.md`: persistent evidence/resume convention.

These files are examples, not a drop-in security boundary or complete orchestrator.
The worker must have separately configured permitted file tools and a real workspace.
The orchestrator must implement acceptance, checkpoint storage and safe command policies.
The Pydantic script intentionally does not run shell commands, so claims requiring runtime
checks remain NOT_VERIFIED until read-only tools or a deterministic test runner are added.

Read WORKFLOW.md and adapt model IDs, allowed tools, sandbox rules and tests to your installation.
- `openai_sdk_example.py`: independent SDK runs with typed worker and verifier outputs; no tools wired.
- `anthropic_sdk_example.py`: Claude Agent SDK programmatic `AgentDefinition` example with bounded, read-only delegations.
