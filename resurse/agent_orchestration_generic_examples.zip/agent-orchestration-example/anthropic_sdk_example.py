"""Claude Agent SDK demonstration of manager-style delegation using AgentDefinition.
Install: pip install claude-agent-sdk
Requires an appropriately authenticated Claude Agent SDK environment.
This example authorizes read-only code exploration only; no implementation tools.
"""
import asyncio
from claude_agent_sdk import AgentDefinition, ClaudeAgentOptions, query

async def main():
    options = ClaudeAgentOptions(
        allowed_tools=['Agent', 'Read', 'Grep', 'Glob'],
        agents={
            'explorer': AgentDefinition(
                description='Find one exact symbol/path, then return evidence.',
                prompt='Be read-only. Search narrowly, return paths and facts. Do not edit.',
                tools=['Read', 'Grep', 'Glob'],
                model='haiku',
            ),
            'verifier': AgentDefinition(
                description='Assess one supplied requirement using read-only source evidence.',
                prompt='Check original criteria. Claims alone are not proof. Return '
                       'PASS/FAIL/NOT_VERIFIED with evidence. Do not edit.',
                tools=['Read', 'Grep', 'Glob'],
                model='sonnet',
            ),
        },
        system_prompt='You are MAIN. Delegate bounded facts to explorer, and independent '
                      'requirement checks to verifier. You own the final ledger and '
                      'never mark ACCEPTED without adequate evidence.',
    )
    async for message in query(
        prompt='Find the current normalization function and ask the verifier '
               'whether there are explicit whitespace regression tests. '
               'Report uncertainty without modifying files.',
        options=options,
    ):
        if hasattr(message, 'result') and message.result:
            print(message.result)

if __name__ == '__main__':
    asyncio.run(main())
