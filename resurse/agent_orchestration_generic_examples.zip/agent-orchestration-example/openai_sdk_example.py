"""OpenAI Agents SDK demonstration: separate manager-controlled worker and verifier runs.
Install: pip install openai-agents pydantic
Needs valid OpenAI API credentials and accessible model.
The example has no code/file tools, so it is an orchestration skeleton, not an autonomous coder.
"""
import asyncio
from pydantic import BaseModel
from typing import Literal
from agents import Agent, Runner

class WorkerClaim(BaseModel):
    task_id: str
    status: Literal['CLAIMED_DONE', 'PARTIAL', 'BLOCKED', 'FAILED']
    evidence: list[str]
    exact_next: str

class Verification(BaseModel):
    verdict: Literal['PASS', 'FAIL', 'NOT_VERIFIED']
    evidence: list[str]

worker = Agent(
    name='bounded-worker',
    model='gpt-6-luna',
    instructions='Handle only assigned task; do not self-approve. '
                 'Without tools, do not claim files changed or tests executed.',
    output_type=WorkerClaim,
)
verifier = Agent(
    name='independent-verifier',
    model='gpt-6-luna',
    instructions='Judge original criteria independently. A worker claim is not proof. '
                 'If tools/evidence are insufficient, return NOT_VERIFIED.',
    output_type=Verification,
)

async def main():
    packet = 'TASK_ID=T-001. Explain how to test whitespace normalization. No file tools.'
    # Deliberately separate runs with no shared conversation/session history.
    claim = (await Runner.run(worker, packet, max_turns=8)).final_output
    verdict = (await Runner.run(
        verifier, f'Original criteria: {packet}\nWorker claim: {claim.model_dump_json()}',
        max_turns=6,
    )).final_output
    print('Claim:', claim.model_dump_json(indent=2))
    print('Assessment:', verdict.model_dump_json(indent=2))
    # MAIN must require deterministic checks before granting ACCEPTED.

if __name__ == '__main__':
    asyncio.run(main())
